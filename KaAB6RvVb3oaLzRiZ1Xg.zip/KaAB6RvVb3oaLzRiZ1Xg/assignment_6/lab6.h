#ifndef LAB6_H
#define LAB6_H

int singleton(std::vector<int> numbers){

    int position = 0;
    
    while(numbers.size() != 1){
        
        for (int i = 1; i < numbers.size() ; i++){
                
            if(numbers[i] == numbers[position] ){
                    
                numbers.erase(numbers.begin() + i);
    
                numbers.erase(numbers.begin() + position);
                
            }
            
            else{
                
                std::swap(numbers.front(),  numbers[i - 1]);
                   
            }
            
        }
        
    }

    return numbers[0];

}

int missing(std::vector<int> numbers){

    for (int i = 0 ; i < numbers.size() ; i++){

        if(numbers[0] == 1){

            return 0;

        }

        else{

            if(numbers[i] + 1 != numbers[i+1]){

               int missing_n = numbers[i+1] - 1;

                return missing_n;

            }

        }

    }

}

bool containsDuplicate(std::vector<int> numbers){

    int position = 0;

    while(position < numbers.size()){

        for (int i = 1 ; i < numbers.size() ; i++){

            if(numbers[i] == numbers[position]){

                return true;

            }

            else{
                
                position = position + 1;
                
            }

        }

    }

    return false;

}

std::vector<int> compress_1(std::vector<int> numbers){

    std::vector<int> result;

    std::vector<int> constant;

    std::vector<int> new_list;

    int i = 1;

    int position = 0;

    while(i < numbers.size()){

        if(numbers[i] != numbers[position] + 1){

            constant.insert(constant.begin() , numbers[position]);

            new_list.push_back(numbers[i]);

            new_list.push_back(numbers[i+1]);

        }

        position = position + 1;

        i = i + 1;

    }

    result.push_back(numbers.front());

    result.push_back(constant[0]);

    result.push_back(new_list.front());

    result.push_back(numbers.back());

    return result;

}


std::vector<int> compress(std::vector<int> numbers){

    std::vector<int> result;

    for (int i = 0; i < numbers.size() ; i++){

        if (numbers[i]+1 == numbers[i+1]){

            result.push_back(numbers.front());

            result.push_back(numbers.back());

            return result;

        }

    }

    return compress_1(numbers);

}

std::vector<int> sort(std::vector<int> numbers){

    for (int i  = 0 ; i < numbers.size()-1 ; i++){

        for (int j = 0 ; j < numbers.size()-1 ; j++){

            if (numbers[j] > numbers[j+1]){

                std::swap(numbers[j] , numbers[j+1]);

            }

        }

    }

    return numbers;

}

std::vector<int> decompress(std::vector<int> numbers){

    std::vector<int> left;

    std::vector<int> right;

    int len = numbers.size()/2;

    for(int i = 0 ; i < len ; i++){

        left.push_back(numbers[i]);

        if (left[i]+1 != left[i+1]){

            left.push_back(left[i] + 1);

            sort(left);

        }

    }

    for(int j = len ; j < numbers.size() ; j++){

        right.push_back(numbers[j]);


    }

    right.push_back(missing(right));

    right = sort(right);

    left.insert(left.end() , right.begin() , right.end() );

    return left;

    
}



int detectError(std::vector<int> numbers){

    if(containsDuplicate(numbers)){

        for (int i  = 0 ; i < numbers.size()-1 ; i++){

            for (int j = 0 ; j < numbers.size()-1 ; j++){

                if (numbers[j] > numbers[j+1]){

                    std::swap(numbers[j] , numbers[j+1]);
                }

            }

        }
    }

    for (int i  = 0 ; i < numbers.size(); i++){

        if (numbers[i]+1 != numbers[i+1]){

            return numbers[i] + 1;

        }

    }


    
}

#endif
