#include <iostream>
#include <vector>
#include "lab6.h"

using namespace std;

int main(){

    vector<int> numbers;

    numbers.push_back(1);
    numbers.push_back(3);
    numbers.push_back(5);
    numbers.push_back(7);
    // numbers.push_back(5);
    // numbers.push_back(6);


    vector<int> result = decompress(numbers);

    for(int i = 0 ; i < result.size() ; i++){

        cout << result[i] << endl;

    }

    // cout<< detectError(numbers) << endl;


    return 0 ;

}
