#include <iostream>

#include <string>

#include "lab5.h"

using namespace std;

int main(){

    string s1, s2;

    cout << "Please enter Full Name: ";

    getline(cin , s1);

    cout << "Second String: ";

    cin >> s2;

    cout << extractLastName(s1 , s2) << endl;

    return 0;
}
