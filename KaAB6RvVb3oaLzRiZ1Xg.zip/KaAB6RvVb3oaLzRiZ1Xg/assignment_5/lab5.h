#ifndef LAB5_H
#define LAB5_H

#include <string>

int countVowels(std::string s){

    int total = 0;

    std::string upper = "";

    std::string vowels = "AEIOU";

    for (int i = 0; i < s.size() ; i++){

        upper += toupper(s[i]);

        for (int j = 0; j < 5; j++){
            
            if (upper[i] == vowels[j] ){

                total = total + 1;
               
            }

        }

    }
    
    return total;

}


bool isStable(std::string s){

    std::string left = "";

    std::string right = "";

    int len = s.size()/2;

    if (s.size() % 2 == 0){

        for (int i = 0 ; i < len ; i++){

            left += s[i];

        }

        for (int j = len ; j < s.size(); j++){

            right += s[j];

        }

        if (countVowels(left) == countVowels(right)){

            return true;

        }

        else{return false;}

    }

    else{

        for (int i = 0 ; i < len ; i++){

            left += s[i];

        }

        for (int j = len+1; j < s.size() ; j++){

            right += s[j];

        }

        if (countVowels(left) == countVowels(right)){

            return true;

        }

        else{return false;}

    }

}

bool hasDoubleLetters(std::string s){

    for (int i = 0 ; i < s.size() ; i++){

        for (int j = 0 ; j < i ; j++){

            if (s[j] == s[i]){

                if (j+1 == i){

                    return true;

                }
            }
        }
    }

}

std::string interleave(std::string word1, std::string word2){

    std::string together = word1 + word2;

    for (int i  = 0 ; i < together.size()-1 ; i++){

        for (int j = 0 ; j < together.size()-1 ; j++){

            if (together[j] > together[j+1]){

                std::swap(together[j] , together[j+1]);

            }

        }
    }

    return together;

}

std::string lcp(std::string s1, std::string s2){

    std::string common = "";


    if (s1.size() > s2.size()){

        for (int i = 0 ; i < s2.size() ; i++){

            if (s1[i] == s2[i]){

                common = common + s1[i];

            }

        }

    }

    else{

        for (int i = 0 ; i < s1.size() ; i++){

            if (s1[i] == s2[i]){

                common = common + s1[i];

            }

        }

    }
    
    return common;

}

std::string email_clean(std::string email){

    std::string email_clean = "";

    std::string upper = "";

    upper += toupper(email[1]);

    for (int i = 0 ; i < email.size() ; i++){

        if (email[i] == '@'){

            for (int j = 2 ; j < i; j++){

                email_clean = email_clean + email[j];

            }

        }


    }

    for (int i = 0; i < email_clean.size() ; i++){

        if (email_clean[i] == '-'){

            for (int j = i ; j < email_clean.size(); j++){

                email_clean[i+1] = toupper(email_clean[i+1]);

            }

        }

    }

    return upper + email_clean;

}

std::string extractLastName(std::string full_name, std::string email){

    std::string email_after = email_clean(email);

    std::string left = "";

    std::string right = "";

    std::string upper = "";

    std::string new_email = "";



    
    if (email_after.size() <= 9){

        return email_after;

    }


    else{

        for (int i = 0; i < email_after.size() ; i++){

            if (email_after[i] == '-'){

                return email_after;

            }

        }

        if (email_after.size() < 14){

            int len = (email_after.size())/2;

            upper += toupper(email_after[len]);



            for (int i = 0 ; i < len ; i++){

                left = left + email_after[i];

            }

            for (int j = len ; j < email_after.size(); j++){

                right = right + email_after[j+1];

            }

            new_email = left + ' ' + upper + right;

            return new_email ;
        }

        else{

            int len = (email_after.size())/2;

            upper += toupper(email_after[len+1]);

            for (int i = 0 ; i <= len ; i++){

                left += email_after[i];

            }

            for (int j = len+1 ; j < email_after.size(); j++){

                right = right + email_after[j+1];

            }

            new_email = left + ' ' + upper + right;

            return new_email;

        }


    }

}

#endif