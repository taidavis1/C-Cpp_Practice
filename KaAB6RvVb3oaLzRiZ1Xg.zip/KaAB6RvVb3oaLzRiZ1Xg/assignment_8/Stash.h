#ifndef STASH_H
#define STASH_H
#include <ostream>
#include <vector>
#include <list>
#include <algorithm>

struct Stash{

    int x;

    char letter;

    bool f;

    int count;

    int capacity;

    float z;

    std::string str;

    void** temp;

    std::vector<std::string> type;

    Stash(){

        count = 0;

        capacity = 1;

        temp = new void*[capacity];

    }

    void append(int x){

        int y = count;

        temp[y] = new int(x);

        type.push_back("int");

        count = count + 1;

        capacity = capacity*2;


    }

    void append(std::string str){

        int y = count;

        temp[y] = new std::string(str);

        type.push_back("str");

        count = count + 1;

        capacity = capacity*2;

    }

    void append(char letter){

        int y = count;

        temp[y] = new char(letter);

        type.push_back("char");

        count = count + 1;

        capacity = capacity*2;

    }

    void append(Stash s){

        int y = count;

        temp[y] = new Stash(s);

        type.push_back("stashes");

        count = count + 1;

        capacity = capacity*2;

    }

    void append(bool f){

        int y = count;

        temp[y] = new bool(f);

        type.push_back("bool");

        count = count + 1;

        capacity = capacity*2;

    }

    int sumint(Stash& s){

        int total = 0;

        for (int i = 0 ; i < s.count; i++){

            if(s.type[i] == "int"){

                total = total + *((int*)s.temp[i]);

            }

        }

        return total;

    }

    Stash quicksort(Stash& s){

        for(int i = 0; i < s.count; i++){

            for(int j = 0; j < s.count-1 ; j++ ){

                if(s.type[i] == "int"){

                    if(*((int*)s.temp[j]) > *((int*)s.temp[j+1])){

                        std::swap(*((int*)s.temp[j]) , *((int*)s.temp[j+1]));

                    }
                    
                }

            }

        }

        return s;

    }

    Stash last_element(Stash& s){

        Stash last;

        if(s.type[s.count-1] == "int"){

           last.append(*((int*)s.temp[count-1]));

        }

        else if(s.type[s.count-1] == "char"){

           last.append(*((char*)s.temp[count-1]));

        }

        else if(s.type[s.count-1] == "str"){

           last.append(*((std::string*)s.temp[count-1]));

        }

        else if(s.type[s.count-1] == "int"){

           last.append(*((int*)s.temp[count-1]));

        }

        else if(s.type[s.count-1] == "bool"){

           last.append(*((bool*)s.temp[count-1]));

        }

        else if(s.type[s.count-1] == "stashes"){

           last.append(*((Stash*)s.temp[count-1]));

        }

        return last;


    }

    ~Stash(){

    }

};

std::ostream& operator<<(std::ostream& os, const Stash& s){

    int i = 0;

    os << "[";

    while(i < s.count){

        if(s.count == 1){

            if(s.type[i] == "int"){

                os << *((int*)s.temp[i]) ;

            }

            else if(s.type[i] == "stashes"){

                os << *((Stash*)s.temp[i]);

            }

            else if(s.type[i] == "char"){

                os <<"'"<<*((char*)s.temp[i])<<"'";

            }

            else if(s.type[i] == "bool"){

                if(*((bool*)s.temp[i]) == true){

                    os <<"True";

                }

                else{

                    os <<"False";

                }

            }

            else if (s.type[i] == "str"){

                os <<*((std::string*)s.temp[i]);


            }

        }

        else{

            if(s.type[i] == "int"){

                if(i != s.count-1){

                    os << *((int*)s.temp[i]) << ", ";

                }

                else{

                    os << *((int*)s.temp[i]);

                }

            }

            else if(s.type[i] == "stashes"){

                if(i != s.count-1){

                    os << *((Stash*)s.temp[i]) << ", ";

                }

                else{

                    os << *((Stash*)s.temp[i]);

                }


            }

            else if(s.type[i] == "char"){

                if(i != s.count-1){

                    os <<"'"<<*((char*)s.temp[i])<<"'" << ", ";

                }

                else{

                    os <<"'"<<*((char*)s.temp[i])<<"'";

                }

            }

            else if(s.type[i] == "bool"){

                if(i != s.count-1){

                    if(*((bool*)s.temp[i]) == true){

                        os <<"True"<< ", ";

                    }

                    else{

                        os <<"False"<< ", ";

                    }

                }

                else{

                    if(*((bool*)s.temp[i]) == true){

                        os <<"True";

                    }

                    else{

                        os <<"False";

                    }

                }

            }

            else if (s.type[i] == "str"){

                if(i != s.count-1){

                    os << "'" << *((std::string*)s.temp[i]) << "'" << ", ";

                }

                else{

                    os << "'" << *((std::string*)s.temp[i]) << "'";

                }
                
            }

        }

        i = i + 1;

    }

    os << "]";

    return os;

}

#endif
