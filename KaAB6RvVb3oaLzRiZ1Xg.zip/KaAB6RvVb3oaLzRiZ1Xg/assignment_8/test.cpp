#include <algorithm>
#include <iostream>
#include "Stash.h"

using namespace std;

int main(){
    Stash s;
    Stash temp;
    temp.append(15);
    temp.append(12);
    temp.quicksort(temp);
    s.append(5);
    s.append(7);
    s.append('A');
    s.append(temp);
    cout << temp << endl;
    cout << s << endl;
    cout<< s.capacity << endl;
    cout << s.sumint(s) << endl;
    cout<< s.last_element(s) <<endl;
    return 0;
}