#ifndef PLAYER_H
#define PLAYER_H

#include <string>
#include <ostream>
#include "Dist.h"
#include "Date.h"

struct Player{
    
    std::string name;
    Dist height;
    Date date;

    Player(){
        this->name = "";
        this->height = Dist();
        this->date = Date();
    }

    Player(std::string name, int feet, int inches , int years , int months , int days){
        this->name = name;
        this->height = Dist(feet, inches);
        this->date = Date(years , months , days);
    }

    Player(const Player& other){
        name = other.name;
        height = other.height;
        date = other.date;
    }

    ~Player(){

    }

};

bool operator != (const Player& p1 , const Player& p2){

    if (p1.name != p2.name){

        return true;

    }

    else{return false;}

}

bool operator == (const Player& p1 , const Player& p2){

    if (p1.name == p2.name){

        return true;

    }

    else{return false;}

}

std::ostream& operator<<(std::ostream& os, const Player& p){
    os << p.name << " - " << p.height << " - " << p.date;
    return os;
}

#endif
