#ifndef DATE_H
#define DATE_H
#include <ostream>
#include "Duration.h"

struct Date{

    int months;

    int years;

    int days;

    Date(){

        months = 0;

        years = 0;

        days = 0;

    }

    Date(int years, int months, int days){

        this->years = years;

        this->months = months;

        this->days = days;

    }

    Date(const Date& other){

        years = other.years;

        months = other.months;

        days = other.days;

    }

    Duration operator-(Date d) const{

        Duration dura;

        int i = years - d.years;

        int j = days - d.days;

        dura.years = i;

        dura.days = j; 

        return dura;

    }

    ~Date(){

    }

};


std::ostream& operator<<(std::ostream& os, const Date& d){

    os << d.years << "-" << d.months << "-" << d.days;

    return os;

}

#endif