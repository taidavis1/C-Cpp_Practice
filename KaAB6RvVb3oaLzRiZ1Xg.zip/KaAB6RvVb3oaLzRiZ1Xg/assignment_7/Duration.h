#ifndef DURATION_H
#define DURATION_H

#include <ostream>
#include "Date.h"

struct Duration{

    int years;

    int days;


    Duration(){

        years = 0;

        days = 0;

    }

    Duration(int years, int days){

        this->years = years;

        this->days = days;

    }

    Duration(const Duration& other){

        years = other.years;

        days = other.days;

    }

    Duration operator+(const Duration dt){

        int i = years + dt.years;

        int c = days + dt.days;

        return Duration(i,c);

    }

    Duration operator/(int d){

        int i = years / d;

        int f = days/ d;

        return Duration(i , f);
        
    }



    ~Duration(){

    }

};

std::ostream& operator<<(std::ostream& os, const Duration& d){

    os << d.years << "," << d.days;

    return os;

}



#endif
