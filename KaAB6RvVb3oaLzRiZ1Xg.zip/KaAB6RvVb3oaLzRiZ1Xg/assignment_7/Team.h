
#ifndef TEAM_H
#define TEAM_H

#include <ostream>
#include "Player.h"
#include "Duration.h"
#include "Date.h"

struct Team{
    Player* players;
    int count;
    int capacity;

    Team(){
        
        count = 0;

        capacity = 1;

        players = new Player[capacity];

    }

    Team(const Team& other){
        count = other.count;
        players = new Player[count];
        for (int i = 0; i < count; i++){
            players[i] = other.players[i];
        }
    }

    Dist averageHeight() const {
        Dist total;
        for(int i = 0; i < count; i++){
            total = total + players[i].height;
        }
        
        return total / count;
    }

    Player getRandom(){

        std::srand(time(NULL));

        // std::cout << std::rand() % count << std::endl;

        return players[std::rand() % count];

    }

    Duration averageAge(const Date& today){

        Duration total;

        for(int i = 0 ; i < count ; i++){

            total = total + (today - players[i].date);

        }

        std::cout << total << std::endl;

        return total / count;

    }


    void add(Player p){

        players[count] = p;
        
        count++;

        if (count == capacity){
            // We have run out of space, so we double our storage

            int oldCapacity = capacity;
            capacity *= 2;

            Player* temp = new Player[capacity]; // This is twice as big as the original

            // Copy all contents of the players array into temp
            for(int i = 0; i < oldCapacity; i++){
                temp[i] = players[i];
            }

            // Move players pointer to the new storage, delete the old storage
            
            Player* oldStorage = players;

            players = temp;

            // Release the old storage space
            delete[] oldStorage;

        }
    }

    void remove(Player p){

        capacity = capacity / 2;

        Player* temp = new Player[capacity];

        for(int i = 0 ; i < count ; i++){

            if (players[i] == p){

                std::swap(players[i] , players[i+1]);

            }

            temp[i] = players[i];

        }

        count = count - 1;

        Player* oldStorage = players;

        delete[] oldStorage;

        players = temp;

    }

};

std::ostream& operator<<(std::ostream& os, const Team& t){
    for (int i = 0; i < t.count; i++){

        os << t.players[i] << std::endl;
        
    }

    return os;
}

#endif
