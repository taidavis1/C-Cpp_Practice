#include <iostream>
#include "Team.h"

using namespace std;

int main(){

    Team dreamTeam;

    dreamTeam.add(Player("Michael Jordan", 6, 6 , 2001 , 12 , 16));
    dreamTeam.add(Player("Charles Barkley", 6, 6, 1998 , 10 , 20));
    dreamTeam.add(Player("Larry Bird", 6, 9, 2002 , 8 , 16));
    dreamTeam.add(Player("Magic Johnson", 6, 9, 1988 , 5 , 20));
    dreamTeam.remove(Player("Larry Bird", 6, 9,1988,5,20));

    cout << dreamTeam.capacity << endl;

    cout << "Hello " << endl;
    cout << dreamTeam <<endl;

    cout << dreamTeam.averageHeight() << endl;

    cout<< dreamTeam.getRandom() << endl;

    // dreamTeam.remove(Player("Larry Bird", 6, 9));

    // dreamTeam.remove(Player("Michael Jordan", 6, 6));

    // dreamTeam.add(Player("Charles Barkley", 6, 6));

    cout << dreamTeam.averageAge(Date(2021,11,28)) << endl;

    // Team backup = dreamTeam;

    // dreamTeam.add(Player("Patrick Ewing", 7, 1));

    // cout << dreamTeam << endl;
    // cout << backup << endl;

    // cout << dreamTeam.averageHeight() << endl;

    return 0;

}
