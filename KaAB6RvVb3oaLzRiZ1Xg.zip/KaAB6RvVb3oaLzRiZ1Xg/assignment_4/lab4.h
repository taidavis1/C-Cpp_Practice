#ifndef LAB4_H
#define LAB4_H

#include <iostream>
#include <cmath>

int simple_lock(int x1, int x2, int x3, int y1, int y2, int y3){

    int current_1 = 0;

    int current_2 = 0;

    int current_3 = 0;

    while (x1 <= 9 && x2 <= 9 && x3 <= 9 && y1 <= 9  && y2 <= 9 && y3 <= 9){

        if ( (x1 > y1) || (y1 > x1) ){

            if (x1 > y1){

                for (int i = 0 ; i < x1 ; i++){

                    if (y1 + i == x1){

                        current_1 = i;

                    }    

                    if (current_1 > 4){

                        current_1 = 10 + y1-x1-1;

                    }

                }

            }

            if (y1 > x1){

                for (int i = 0; i < y1 ; i++){

                    if (x1 + i == y1){

                        current_1 = i;
                    
                    }

                    if (current_1 > 4){

                        current_1 = 10 + x1-y1-1;

                    }

                }

            }

        }

        if ( (x2 > y2) || (y2 > x2) ){

            if (x2 > y2){

                for (int i = 0 ; i < x2 ; i++){

                    if (y2 + i == x2){

                        current_2 = i;

                    }

                    if (current_2 > 4){

                        current_2 = 10 + y2-x2-1;

                    }

                }

            }

            if (y2 > x2){

                for (int i = 0 ; i < y2 ; i++){

                    if (x2 + i == y2){

                        current_2 = i;

                    }

                    if (current_2 > 4){

                        current_2 = 10 + x2-y2-1;

                    }

                }

            }

        }

        if ( (x3 > y3) || (y3 > x3) ){

            if (x3 > y3){

                for (int i = 0 ; i < x3 ; i++){

                    if (y3 + i == x3){

                        current_3 = i;

                    }

                    if (current_3 > 4){

                        current_3 = 10 + y3-x3-1;

                    }

                }

            }

            if (y3 > x3){

                for (int i = 0 ; i < y3 ; i++){

                    if (x3 + i == y3){

                        current_3 = i;

                    }

                    if (current_3 > 4){

                        current_3 = 10 + x3-y3-1;

                    }

                }

            }

        }

        return current_1 + current_2 + current_3;

    }

}

int get1digit(int x){

    while(x >= 10){

        x = x/10;

    }

    return x;

}

int digitnum(int x){

    int total = 0;

    while (x >= 10){

        x = x/10;

        total = total + 1;

    }

    return total;

}

int combo_lock(int current, int unlock){

    int total = 0;

    int test = 0;

    int new_current = current+1;

    int new_unlock = unlock+1;

    int digit_number = digitnum(current);

    int last_digit = current % 10;

    int last_lock = unlock % 10;

    while (digit_number != 0){

        int first_digit = get1digit(current);

        int first_digit_2 = get1digit(unlock);

        current = current-(first_digit * (pow(10,digit_number)));

        unlock = unlock-(first_digit_2 * (pow(10,digit_number)));

        test = simple_lock(first_digit,0,0,first_digit_2,0,0);

        total = test + total;

        digit_number--;
        
    }


    return total + simple_lock(last_digit,0,0 , last_lock,0,0);

    
}

bool is_perfect(int n){

    int sum = 0;

    for (int i = 1 ; i <= n-1 ; i++){

        if (n % i == 0){

            sum = sum + i;

        }

    }

    if (sum == n){

        return true;

    }

    else{return false;}

}

int next_perfect(int n){

    while (n > 1){

        int new_n = n + 1;

        if (is_perfect(new_n)){

            return new_n;

        }

        n++;

    }


}

bool is_prime(int x){

    if (x == 1){

        return false;

    }

    else{

        for (int i = 2 ; i <= x-1 ; i++){

            if (x % i == 0){

                return false;

            }

        }

        if ( (x % x == 0) && (x % 1 == 0) ){

            return true;

        }

    }
    
}

int next_prime (int n){

    while (n > 1){

        int new_n = n + 1;

        if (is_prime(new_n)){

            return new_n;

        }

        n++;

    }

}

bool is_power(int number, int base){

    if (number % base == 0){

        while (number != 1){

            if (number % base != 0){

                return false;

            }

            number = number / base;

        }

    }

    else{return false;}

}

int gcd(int a, int b) {

    if (b == 0)

        return a;
        
    return gcd(b, a % b);
}

bool coprime(int x, int y){

    if (gcd(x,y) == 1){

        return true;

    }

    else{return false;}


}

int phi(int n){

    int total = 0;

    for (int i = 1 ; i < n ; i++){

        if (coprime(i,n)){

            total = total + 1;

        }

    }

    return total;


}

double sqrt(double a, double x, double epsilon){

    while (a > x){

        x = (x + (a/x))/2;

        if (x-(a/x) < epsilon){

            return x;

        }

    }


}

#endif

