
#include <iostream>

#include "assignment_3.h"

#include <string>

using namespace std;

int main(){
    
    float x1 , y1 , x2 , y2;

    cout << "Enter x:";

    cin >> x1;

    cout << "Enter x:";

    cin >> y2;

    cout << "Enter x:";

    cin >> x2;

    cout << "Enter x:";

    cin >> y2;

    cout << sameQuad(x1,y1,x2,y2) << endl;


    return 0;


}