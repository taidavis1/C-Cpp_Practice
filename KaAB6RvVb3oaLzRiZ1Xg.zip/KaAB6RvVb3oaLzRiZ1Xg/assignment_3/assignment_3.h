#ifndef ASSIGNMENT3_H
#define ASSIGNMENT3_H


float wages(int hours, float rate){

    if (hours > 40 ) {

        float rate_above = 1.5;

        int hours_over = hours - 40;

        float total_over_time = (rate_above * rate) * hours_over;

        return (40 * rate) + total_over_time;

    }

    else{

        return hours * rate;

    }

}


bool canDonateBlood(std::string donor, std::string recipient){

    if (donor == "A"){

        if (recipient == "A"){

            return true;

        }

        else if (recipient == "AB"){

            return true;

        }

        else{

            return false;
            
        }

    }

    else if (donor == "B"){

        if (recipient == "B"){

            return true;

        }

        else if (recipient == "AB"){

            return true;

        }

        else{

            return false;

        }

    }

    else if (donor == "AB"){

        if (recipient == "AB"){

            return true;

        }

        else{
            
            return false;
            
        }

    }

    else{

        return true;

    }

}


bool leap(int year){

    if (year % int(4) == 0){

        if (year % int(100) != 0){

            return true;

        }

        else if (year % int(400) == 0){

            return true;

        }

        else{

            return false;

        }

    }

    else{

        return false;
        
    }

}

int daysInMonth(int month, int year){

    if ( (month == 1) || (month == 3 ) || (month == 5) || (month == 7) || (month == 8) || (month == 10) || (month == 12)){

        return 31;

    }

    else if (month == 2){

        if (leap(year)){

            return 29;

        }

        else{

            return 28;

        }

    }

    else{

        return 30;

    }

}

bool pointInRect(float x, float y, float rx, float ry, float rw, float rh){

    float bottom_right_x = rx+rw;

    float bottom_right_y = ry-rh;

    if ( (x >= rx) && (x <= bottom_right_x) && (y <= ry) && (y >= bottom_right_y) ){

        return true;

    }

    else{

        return false;

    }

}

bool rectInRect(float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2){


    if ( ( pointInRect(x1 , y1 , x2 , y2 , w2 , h2) )  ){

        float  bottom_right_x_1 = x1 + h1;

        float bottom_right_y_1 = y1 - h1;

        if ( pointInRect(bottom_right_x_1 , bottom_right_y_1 , x2 , y2 , w2 , h2) ){

            return true;

        }

        else{

            return false;

        }

    }

    else{

        return false;

    }

}

bool overlap(float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2){

    float x_1 = x1 + w1;

    float x_2 = x2 + w2;

    float left_bottom_y = y1 - h1;

    float left_bottom_y_2 = y2 - h2;

    if ( pointInRect(x1 , y1 , x2 , y2 , w2 , h2) ){

        if ( x_1 > x_2 ){

            return true;

        }
    }

    else if( ( pointInRect(x1 , left_bottom_y , x2 , y2 , w2 , h2)) || (pointInRect(x2 , left_bottom_y_2 , x1 , y1 , w1 , h1))){

        return true;

    }
    
    else{

        return false;

    }

}

bool sameQuad(float x1 , float y1 , float x2 , float y2){

    if ( (x1 <= 0)  && (x2 <= 0) ){

        if ( (y1 >= 0) && (y2 >= 0) ){

            return true;

        }

        else if ( (y1 <= 0 ) && (y2 <= 0)){

            return true;

        }

    }


    else if ( (x1 >= 0)  && (x2 >= 0) ){

        if ( (y1 >= 0) && (y2 >= 0) ){

            return true;

        }

        else if ( (y1 <= 0 ) && (y2 <= 0)){

            return true;

        }

    }


}

#endif
