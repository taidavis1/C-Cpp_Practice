#include <iostream>
#include <vector>
using namespace std;

int main(){

    vector<int> nums;

    int total = 0;

    int x;

    while(true){

        cout << "Enter Ur Number:" << endl;

        cin >> x;

        if (x != -1){

            nums.push_back(x);

        }

        else{break;}

    }

    for(int i = 0; i < nums.size(); i++){

        total = total + nums[i];

    }

    cout << "Yours numbers add up to " << total << endl;


    return 0;
}
