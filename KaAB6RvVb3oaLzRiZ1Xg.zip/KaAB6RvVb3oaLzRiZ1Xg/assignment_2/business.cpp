#include <iostream>

#include <iomanip>

#include <string>

#include <cmath>

using namespace std;

int main(){

    cout << "Enter your current bank balance: ";

    int bank_balance;

    cin >> bank_balance;

    cout << "Projected monthly operational expenses: ";

    int monthly_expenses;

    cin >> monthly_expenses;

    cout << "Projected monthly income from operations: ";

    int monthly_income;

    cin >> monthly_income;

    cout << "Gross burn rate: " << "$" << monthly_expenses << endl;

    int netburn = monthly_expenses - monthly_income;

    cout << "Net burn rate: " << "$" << netburn << endl;

    int runway = bank_balance / netburn;

    cout << "Projected runway: " << runway << " months" << endl;

    return 0; 


}