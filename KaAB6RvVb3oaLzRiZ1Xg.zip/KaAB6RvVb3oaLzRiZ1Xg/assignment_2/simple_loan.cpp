#include <iostream>

#include <iomanip>

using namespace std;

int main(){

    cout << "Enter loan amount: ";

    int loan_amount;

    cin >> loan_amount;

    cout << "Enter load period (months): ";

    int period;

    cin >> period;

    float owe_amount = float(loan_amount) / float(period);

    cout << setprecision(2) << fixed;

    cout << "You owe $" << owe_amount << " per month." << endl;

    return 0;

}