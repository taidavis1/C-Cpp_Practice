#include <iostream>

#include <string>

#include <cmath>

#include <iomanip>

using namespace std;

int main(){

    cout << "Enter loan amount: ";

    float loan_amount;

    cin >> loan_amount;

    cout << "Enter load period (months): ";

    float period ;

    cin >> period;

    cout << "Enter annual interest rate (percentage): ";

    float rate;

    cin >> rate;

    float rate_percent = rate/100;

    float monthly_rate = rate_percent/12;

    float first_part = loan_amount * monthly_rate * pow(1+monthly_rate , period);

    float second_part = pow(1+ monthly_rate , period)-1;

    float owe_amount = first_part / second_part;

    cout << setprecision(2) << fixed << "You owe $" << owe_amount << " per month." << endl;

    return 0;

}