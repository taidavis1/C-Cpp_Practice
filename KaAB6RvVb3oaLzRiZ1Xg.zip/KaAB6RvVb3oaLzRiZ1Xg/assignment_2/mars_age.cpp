#include <iostream>

#include <string>

#include <iomanip>

using namespace std;

int main(){

    int ages = 0;

    cout << "Enter your age: " ;

    cin >> ages;

    float years_to_second = 31557600;

    float second_on_mars = 59356800;

    float mars_age = (years_to_second * float(ages)) / second_on_mars;

    cout << setprecision(2) << fixed << "On Mars, you would be about " << mars_age << endl;

    return 0;


}