#include <iostream>
#include <string>

using namespace std;

int main(){

    int ages = 0;

    cout << "Enter your age: ";

    cin >> ages;

    int years_to_second = 31557600;

    int s = years_to_second * ages;

    cout << "You are " << s << " seconds old." << endl;

    return 0 ;

}