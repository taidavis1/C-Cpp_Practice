#include <iostream>
using namespace std;
int main(){
	cout << "Welcome to CSE030!" << endl;
	return 0;
}