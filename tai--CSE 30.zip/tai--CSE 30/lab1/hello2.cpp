#include <iostream>
using namespace std;

int main(){

std::string name;

cout << "Please enter Your name: ";
// This is take in the variable name
cin >> name;

cout << "Welcome to CSE30, " << name << endl;

return 0;

}
